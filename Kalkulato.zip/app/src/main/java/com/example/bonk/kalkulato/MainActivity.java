package com.example.bonk.kalkulato;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    double fn;
    double sn;
    String operator;

    EditText et;
    Button clear;
    Button plus;
    Button minus;
    Button b7;
    Button b8;
    Button b9;
    Button mul;
    Button b4;
    Button b5;
    Button b6;
    Button div;
    Button b1;
    Button b2;
    Button b3;
    Button equal;
    Button b0;
    Button back;
    Button close;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        et= (EditText) findViewById(R.id.et);
        clear= (Button) findViewById(R.id.clear);
        plus= (Button)findViewById(R.id.plus);
        minus= (Button)findViewById(R.id.minus);
        b7= (Button)findViewById(R.id.b7);
        b8= (Button)findViewById(R.id.b8);
        b9= (Button)findViewById(R.id.b9);
        mul= (Button)findViewById(R.id.mul);
        b4= (Button)findViewById(R.id.b4);
        b5= (Button)findViewById(R.id.b5);
        b6= (Button)findViewById(R.id.b6);
        div= (Button)findViewById(R.id.div);
        b1= (Button)findViewById(R.id.b1);
        b2= (Button)findViewById(R.id.b2);
        b3= (Button)findViewById(R.id.b3);
        equal= (Button)findViewById(R.id.equal);
        b0= (Button)findViewById(R.id.b0);
        back= (Button)findViewById(R.id.back);
        close= (Button)findViewById(R.id.close);

        clear.setOnClickListener(this);
        plus.setOnClickListener(this);
        minus.setOnClickListener(this);
        b7.setOnClickListener(this);
        b8.setOnClickListener(this);
        b9.setOnClickListener(this);
        mul.setOnClickListener(this);
        b4.setOnClickListener(this);
        b5.setOnClickListener(this);
        b6.setOnClickListener(this);
        div.setOnClickListener(this);
        b1.setOnClickListener(this);
        b2.setOnClickListener(this);
        b3.setOnClickListener(this);
        equal.setOnClickListener(this);
        b0.setOnClickListener(this);
        back.setOnClickListener(this);
        close.setOnClickListener(this);
    }

    @Override
    public void onClick(View view) {
        String string=et.getText().toString();
        try {
            switch (view.getId()) {
                case R.id.b0:
                    if(string.equals("0"))
                        break;
                    et.setText(string + b0.getText());

                    break;

                case R.id.b1:
                    et.setText(string + b1.getText());
                    break;
                case R.id.b2:
                    et.setText(string + b2.getText());
                    break;
                case R.id.b3:
                    et.setText(string + b3.getText());
                    break;
                case R.id.b4:
                    et.setText(string + b4.getText());
                    break;
                case R.id.b5:
                    et.setText(string + b5.getText());
                    break;
                case R.id.b6:
                    et.setText(string + b6.getText());
                    break;
                case R.id.b7:
                    et.setText(string + b7.getText());
                    break;
                case R.id.b8:
                    et.setText(string + b8.getText());
                    break;
                case R.id.b9:
                    et.setText(string + b9.getText());
                    break;
                case R.id.clear:
                    et.setText("");
                    break;

                case R.id.plus:
                    operator = "+";
                    fn = Double.parseDouble(et.getText().toString());
                    et.setText("");
                    break;
                case R.id.minus:
                    operator = "-";
                    fn = Double.parseDouble(et.getText().toString());
                    et.setText("");
                    break;
                case R.id.mul:
                    operator = "x";
                    fn = Double.parseDouble(et.getText().toString());
                    et.setText("");
                    break;
                case R.id.div:
                    operator = "/";
                    fn = Double.parseDouble(et.getText().toString());
                    et.setText("");
                    break;

                case R.id.back:
                    et.setText(Double.parseDouble(et.getText().toString()) * (-1) + "");
                    break;
                case R.id.equal:
                    sn = Double.parseDouble(et.getText().toString());
                    switch (operator) {
                        case "+":
                            et.setText(checkFloatingPoint(fn + sn));

                            break;
                        case "-":
                            et.setText(checkFloatingPoint(fn - sn));

                            break;
                        case "x":
                            et.setText(checkFloatingPoint(fn * sn));

                            break;
                        case "/":
                            if(sn == 0) et.setText("Nie dzielimy przez 0!");
                            else et.setText(checkFloatingPoint(fn / sn));

                            break;
                    }

                    break;

                case R.id.close:
                    finish();
                    break;

            }




        }

        catch(NumberFormatException e) {};
    }

    public String checkFloatingPoint (double x){

        if (x == (int)x) return String.valueOf((int)x);
        return String.valueOf(x);
    }
}
